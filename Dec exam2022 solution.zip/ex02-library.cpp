#include <iostream>
#include "ex02-library.h"
using namespace std;

// Task 2(a).  Implement this function
void displayTeams(TournamentNode *t) {
    // Write your code here
if(t==nullptr){
    return;
}
displayTeams(t->left);
if(t->nodeType==team) {
    cout<<t->name<<endl;
}
    displayTeams(t->right);
}

// Task 2(b).  Implement this function
unsigned int matches(TournamentNode *t) {
    int m=0;
   if(t==nullptr||t->nodeType==team){
       return 0;
   }

    if(t->nodeType==match) {
        m++;
    }
    m=m+matches(t->left)+matches(t->right);
    return m;

}

// Task 2(c).  Implement this function
string winner(TournamentNode *t) {
    // Replace the following with your code


    if(t==nullptr){
        return "";
    }
    if(t->nodeType==team){
        return t->name;
    }

    if(t->nodeType==match){
       if(t->result==leftWin){
          return winner(t->left);

       }

       else if(t->result==rightWin){
          return winner(t->right);

       }
    }


}

// Task 2(d). Implement this function

    bool wonAnyMatch(TournamentNode *t, string teamName) {
        if (t == nullptr || t->nodeType == team) {
            return false;
        }

        if (t->result == leftWin && t->left->nodeType == team && t->left->name == teamName) {
            return true;
        }

        if (t->result == rightWin && t->right->nodeType == team && t->right->name == teamName) {
            return true;
        }

        return wonAnyMatch(t->left, teamName) || wonAnyMatch(t->right, teamName);
    }

