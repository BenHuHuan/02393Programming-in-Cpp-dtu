#include "ex04-library.h"
#include<algorithm>
/*
// Task 4(a): Constructor implementation
CountingBuffer::CountingBuffer(int defaultValue) : defaultVal(defaultValue) {}

// Task 4(b): write method implementation
void CountingBuffer::write(int v) {
    data.push_back(v);
    freq[v]++;
}

// Task 4(c): frequency method implementation
unsigned int CountingBuffer::frequency(int v) const {
    if (freq.find(v) != freq.end()) {
        return freq.at(v);
    } else {
        return 0;
    }
}

// Task 4(c): mostFrequent method implementation
int CountingBuffer::mostFrequent() const {
    if (!data.empty()) {
        int maxFrequency = 0;
        int mostFrequentValue = defaultVal;

        for (const auto &entry : freq) {
            if (entry.second >= maxFrequency || (entry.second == maxFrequency && entry.first > mostFrequentValue)) {
                maxFrequency = entry.second;
                mostFrequentValue = entry.first;
            }
        }

        return mostFrequentValue;
    } else {
        return defaultVal;
    }
}

// Task 4(d): clear method implementation
void CountingBuffer::clear() {
    data.clear();
    freq.clear();
}

// Destructor
CountingBuffer::~CountingBuffer() {}
Buffer::~Buffer() {}



*/


// Task 4(a).  Write a placeholder implementation of CountingBuffer's
//             constructor and methods
CountingBuffer::CountingBuffer(int value) {
    defaultvalue=value;
}


// Task 4(b).  Write a working implementation of write() and frequency()
void CountingBuffer::write(int v){
    val.push_back(v);
}
unsigned int CountingBuffer::frequency(int v)
{ int times=0;
    vector<int>::iterator it;
    for(it=val.begin();it!=val.end();it++){
        if(v==*it){
            times=times+1;
        }
    }

    return times;
}

// Task 4(c).  Write a working implementation of mostFrequent()
int CountingBuffer::mostFrequent(){
    vector<int> t;
    vector<int>::iterator it;
    if(val.empty()){
        return defaultvalue;
    }
    for(it=val.end();it!=val.begin();it=it-1){
        t.push_back(frequency(*it));
    }
    int max=max_element(t.begin(),t.end())-t.begin();
    return val[val.size()-max];
}

// Task 4(d).  Write a working implementation of clear()
void CountingBuffer::clear() {
    val.clear();
}
// Do not modify
Buffer::~Buffer() {
    // Empty destructor
}
