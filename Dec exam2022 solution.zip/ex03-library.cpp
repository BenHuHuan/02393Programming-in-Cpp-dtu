
#include <iostream>
#include "ex03-library.h"
#include <string>
#include <vector>
#include <algorithm>
using namespace std;


// Task 3(a).  Implement this method
void Locker::putPackage(string lockerID, string sender, string recipient, int unlockCode) {
    vector<string>::iterator it =find(lockerIDs.begin(),lockerIDs.end(),lockerID);
    if(it!=lockerIDs.end()){
        map<string,Package>::iterator that = lockerOccupancy.find(lockerID);
        if(that==lockerOccupancy.end()){
            lockerOccupancy.insert(pair<string,Package>(lockerID,{sender,recipient,unlockCode}));
        }
        else{
            return;
        }
    }
    else{
        return;
    }

}

// Task 3(b).  Implement this method
void Locker::retrievePackage(string lockerID, int unlockCode) {
    map<string,Package>::iterator it= lockerOccupancy.find(lockerID);// Write your code here
    if(it!=lockerOccupancy.end()){
        if(unlockCode==it->second.unlockCode){
            lockerOccupancy.erase(it);
        }
    }
}

// Task 3(c).  Implement this method
void Locker::findPackagesByRecipient(vector<string> recipients) {
    // Write your code here

    map<string,Package>::iterator it;
    for(int i=0;i<recipients.size();i++) {
        for (it = lockerOccupancy.begin(); it != lockerOccupancy.end(); it++) {
            if (recipients[i] == it->second.recipient) {
                cout << it->first<<endl;
            }
        }

    }
}



// Task 3(a). Implement this method
//void Locker::putPackage(string lockerID, string sender, string recipient, int unlockCode) {
    // Check if the lockerID exists in lockerIDs
   // if (find(lockerIDs.begin(), lockerIDs.end(), lockerID) != lockerIDs.end()) {
        // Check if the locker is already occupied
      //  if (lockerOccupancy.find(lockerID) == lockerOccupancy.end()) {
            // Locker is available, so update lockerOccupancy
           // lockerOccupancy[lockerID] = {sender, recipient, unlockCode};
       // }
   // }
//}

// Task 3(b). Implement this method
//void Locker::retrievePackage(string lockerID, int unlockCode) {
    // Check if the lockerID exists in lockerOccupancy
    //if (lockerOccupancy.find(lockerID) != lockerOccupancy.end()) {
        // Check if the unlockCode matches
       // if (lockerOccupancy[lockerID].unlockCode == unlockCode) {
            // Remove the occupancy from lockerOccupancy
           // lockerOccupancy.erase(lockerID);
      //  }
   // }
//}

// Task 3(c). Implement this method
//void Locker::findPackagesByRecipient(vector<string> recipients) {
    //for (const string& lockerID : lockerIDs) {
        //if (lockerOccupancy.find(lockerID) != lockerOccupancy.end()) {
            // Check if the recipient is in the recipients vector
            //if (std::find(recipients.begin(), recipients.end(), lockerOccupancy[lockerID].recipient) != recipients.end()) {
                //cout << lockerID << endl;
            //}
       // }
   // }
//}
// Do not modify
Locker::Locker() {
    this->lockerIDs.push_back("LYNGBY01");
    this->lockerOccupancy["LYNGBY01"] = {"Alice", "Daisy", 1234};
    this->lockerIDs.push_back("LYNGBY02");
    this->lockerOccupancy["LYNGBY02"] = {"Claire", "Alice", 567};
    this->lockerIDs.push_back("LYNGBY03");
    this->lockerOccupancy["LYNGBY03"] = {"Daisy", "Bob", 890};
    this->lockerIDs.push_back("LYNGBY04");
    this->lockerIDs.push_back("LYNGBY05");
    this->lockerOccupancy["LYNGBY05"] = {"Bob", "Daisy", 159};
    this->lockerIDs.push_back("LYNGBY06");
}
// Do not modify
void Locker::display() {
    for (auto it = this->lockerIDs.begin(); it != this->lockerIDs.end(); it++) {
        cout << "Locker '" << *it << "' ";
        if (this->lockerOccupancy.find(*it) == this->lockerOccupancy.end()) {
            cout << "is empty" << endl;
        } else {
            cout << "contains a package from " << this->lockerOccupancy[*it].sender;
            cout << " to " << this->lockerOccupancy[*it].recipient;
            cout << " (unlock code: " << this->lockerOccupancy[*it].unlockCode << ")" << endl;
        }
    }
}

