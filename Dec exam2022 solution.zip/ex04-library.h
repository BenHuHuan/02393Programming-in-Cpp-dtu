#ifndef EX04_LIBRARY_H_
#define EX04_LIBRARY_H_

#include <vector>
#include <unordered_map>


using namespace std;
class Buffer {
public:
    virtual void write(int v) = 0;
    virtual void clear() = 0;
    virtual ~Buffer();
};
class CountingBuffer:public Buffer{
public:
    CountingBuffer(int value);
    void write(int v) ;
    void clear() ;
    unsigned int frequency(int v);
    int mostFrequent();
private:
    vector<int> val;
    int defaultvalue; //you know that you need it

};

/*
class Buffer {
public:
    virtual void write(int v) = 0;
    virtual void clear() = 0;
    virtual ~Buffer();

};

class CountingBuffer : public Buffer {
public:
    CountingBuffer(int defaultValue);

    void write(int v) override;
    unsigned int frequency(int v) const;
    int mostFrequent() const;
    void clear() override;

    ~CountingBuffer();

private:
    int defaultVal;
    std::vector<int> data;
    std::unordered_map<int, unsigned int> freq;
};


// Implement the virtual destructor for Buffer


// ... Rest of your CountingBuffer implementation as provided earlier.
*/



#endif /* EX04_LIBRARY_H_ */

